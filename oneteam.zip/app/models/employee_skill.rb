class EmployeeSkill < ActiveRecord::Base
  attr_accessible :employee_id, :skill_id
  attr_accessible :skill_ids
  belongs_to :employee
  belongs_to :skill
end
