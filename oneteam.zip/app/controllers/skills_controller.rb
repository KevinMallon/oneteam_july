class SkillsController < ApplicationController
  def new
  end
end
