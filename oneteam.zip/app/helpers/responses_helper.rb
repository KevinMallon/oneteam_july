module ResponsesHelper
end
