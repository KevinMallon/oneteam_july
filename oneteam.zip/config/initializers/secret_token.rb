# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OneteamApp::Application.config.secret_token = 'ab464e51fe122ffb40bebff3238fddac68fa3c70faf9fca84a41a62ff6b8e3df2a871b0698e2d5263bddb871a3f9a9967873be05b71e77aafa7e045f766c19fb'
