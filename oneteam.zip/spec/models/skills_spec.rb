require 'spec_helper'

describe Skills do
  pending "add some examples to (or delete) #{__FILE__}"
end
