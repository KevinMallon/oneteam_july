require 'spec_helper'

describe TargetSkill do
  pending "add some examples to (or delete) #{__FILE__}"
end
