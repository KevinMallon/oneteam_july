require 'spec_helper'

describe ReqstatesController do

end
